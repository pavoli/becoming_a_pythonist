# -*- coding: utf-8 -*-

__author__ = 'p.olifer'
__version__ = '1.0'


class Calculator():

    def __init__(self, amount, interest, downpayment, term):
        self.amount = amount
        self.interest = interest
        self.downpayment = downpayment
        self.term = term